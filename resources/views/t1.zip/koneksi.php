<?php
$server = "localhost";
$user = "root";
$pass = "";
$db = "abc.123";

$koneksi = mysqli_connect($server,$user,$pass,$db);

if (mysqli_connect_error()){
    echo "gagal konek ".mysqli_connect_error();
}
?>