<html>
<head>
	<title>CRUD PHP dan MySQLi</title>
</head>
<body>
	<a href="tambah.php">+ TAMBAH PRODUK</a>
	<br/>
	<br/>
	<table border="1" style="margin-bottom:30px;">
		<tr>
			<th>Id</th>
			<th>Nama</th>
			<th>harga</th>
			<th>kategori</th>
			<th>deskripsi</th>
			<th>Opsi</th>
		</tr>
		<?php 
		include 'koneksi.php';
		$no = 1;
		$data = mysqli_query($koneksi,"select * from produk");
		while($d = mysqli_fetch_array($data)){
			?>
			<tr>
				<td><?php echo $d['id']; ?></td>
				<td><?php echo $d['name']; ?></td>
				<td><?php echo $d['price']; ?></td>
				<td><?php echo $d['category']; ?></td>
				<td><?php echo $d['description']; ?></td>
				<td>
					<a href="edit.php?id=<?php echo $d['id']; ?>">EDIT</a>
					<a href="hapus.php?id=<?php echo $d['id']; ?>">HAPUS</a>
				</td>
			</tr>
			<?php 
		}
		?>
	</table>
</body>
</html>