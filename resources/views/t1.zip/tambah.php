<html>
<head>
	<title>CRUD PHP dan MySQLi</title>
</head>
<body>

	<a href="list.php">KEMBALI</a>
	<br/>
	<br/>
	<h3>INPUT MAKANAN</h3>
	<form method="post" action="tambah_aksi.php">
		<table>
        <tr>			
			
			<tr>			
				<td>Nama</td>
                <input type="hidden" name="id">
				<td><input type="text" name="name"></td>
			</tr>
			<tr>
				<td>Harga</td>
				<td><input type="number" name="price"><a>*masukan harga tanpa titik dan 3 digit angka 0, contoh harga 10.000 masukan angka 10 saja.</a></td>
			</tr>
			<tr>
				<td>Kategori</td>
				<td><input type="text" name="category"></td>
			</tr>
            <tr>
				<td>Deskripsi</td>
				<td><input type="text" name="description"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="SIMPAN"></td>
			</tr>		
		</table>
	</form>
</body>
</html>