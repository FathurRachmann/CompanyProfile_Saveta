<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$id = $_POST['id'];
$name = $_POST['name'];
$price = $_POST['price'];
$category = $_POST['category'];
$description = $_POST['description'];
 
// update data ke database
mysqli_query($koneksi,"update produk set name='$name', price='$price', category='$category', description='$description' where id='$id'");
 
// mengalihkan halaman kembali ke index.php
header("location:list.php");
 
?>