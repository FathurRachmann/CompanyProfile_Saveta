<?php $__env->startSection("title"); ?>
Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

<section data-bs-version="5.1" class="header13 cid-t7QT2eNoVu" id="header13-1w" style="background-image: url(<?php echo e(asset('images/mbr.jpg')); ?>)">

    

    
    

    <div class="align-center container-fluid">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-11">
                <h1 class="mbr-section-title mbr-fonts-style mb-3 display-1"><strong>OUR PRODUCTS</strong></h1>
                
                <p class="mbr-text mbr-fonts-style mb-3 display-7">&nbsp;</p>
                
                
            </div>
        </div>
    </div>
</section>

<section data-bs-version="5.1" class="features12 cid-t7QT2fhH1C" id="features13-1x">

    

    
    
    <div class="container">
                    <form action="<?php echo e(url ('cari')); ?>" method="GET">
                        <input type="text" name="cari" placeholder="Cari Guru .." value="<?php echo e(old('cari')); ?>">
                        <input type="submit" value="CARI">
                    </form>
        <div class="row">
            <?php $__currentLoopData = $cupcakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cupcake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card">
                    <a href="<?php echo e(url ('detail?id='.$cupcake->IdCupcake)); ?>">
                        <img src="<?php echo e(asset('images/'.$cupcake->Image)); ?>" class="card-img-top" alt="<?php echo e($cupcake->Image); ?>">
                    </a>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-7">
                                <h5 class="card-title"><?php echo e($cupcake->Name); ?></h5>
                            </div>
                            <div class="col-md-5 text-right">
                                <p class="card-text">Price $<?php echo e($cupcake->Price); ?></p>
                            </div>
                        </div>
                        <a href="<?php echo e(url ('detail?id='.$cupcake->IdCupcake)); ?>" class="btn btn-primary">See Product</a>
                    </div>
                </div>
                <br>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
        </div>
    </div>
</section>

<section><a href="https://mobiri.se"></a><a href="https://mobiri.se"></a></section><script src="<?php echo e(asset('/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>  <script src="<?php echo e(asset('/smoothscroll/smooth-scroll.js')); ?>"></script>  <script src="<?php echo e(asset('/ytplayer/index.js')); ?>"></script>  <script src="<?php echo e(asset('/dropdown/js/navbar-dropdown.js')); ?>"></script>  <script src="<?php echo e(asset('/theme/js/script.js')); ?>"></script>  
  
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tes2\resources\views/category.blade.php ENDPATH**/ ?>