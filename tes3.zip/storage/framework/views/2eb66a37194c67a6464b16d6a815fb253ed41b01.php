<?php $__env->startSection("title"); ?>
Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

<section data-bs-version="5.1" class="header13 cid-t7QT2eNoVu" id="header13-1w" style="background-image: url(<?php echo e(asset('images/mbr.jpg')); ?>)">

    

    
    

    <div class="align-center container-fluid">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-11">
                <h1 class="mbr-section-title mbr-fonts-style mb-3 display-1"><strong>OUR PRODUCTS</strong></h1>
                
                <p class="mbr-text mbr-fonts-style mb-3 display-7">&nbsp;</p>
                
                
            </div>
        </div>
    </div>
</section>

<section data-bs-version="5.1" class="features12 cid-t7QT2fhH1C" id="features13-1x">

    

    
    
    <div class="container">
        <h1>Cupcakes World
            <small class="text-muted">Pick your cupcake</small>
        </h1>
        <div class="row">
            
            <div class="col-md-12">
                <div class="card">
                    <a>
                        <img src="<?php echo e(asset('images/'.$cupcake->Image)); ?>" class="card-img-top" alt="<?php echo e($cupcake->Image); ?>">
                    </a>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-7">
                                <h5 class="card-title"><?php echo e($cupcake->Name); ?></h5>
                            </div>
                            <div class="col-md-5 text-right">
                                <p class="card-text">Price $<?php echo e($cupcake->Price); ?></p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <p class="card-text"><?php echo e($cupcake->Description); ?></p>
                                <br>
                            </div>
                        </div>                    
                        <a href="<?php echo e(url ('listdata')); ?>" class="btn btn-primary">Return back</a>
                    </div>
                </div>
                <br>
            </div>
        
              
        </div>
    </div>
    
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
</section>

<section><a href="https://mobiri.se"></a><a href="https://mobiri.se"></a></section><script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>  <script src="assets/smoothscroll/smooth-scroll.js"></script>  <script src="assets/ytplayer/index.js"></script>  <script src="assets/dropdown/js/navbar-dropdown.js"></script>  <script src="assets/theme/js/script.js"></script>  
  
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tes1\resources\views/detail.blade.php ENDPATH**/ ?>