<?php $__env->startSection("content"); ?>
  <section data-bs-version="5.1" class="menu menu3 cid-t4Ly7ne41J" once="menu" id="menu3-1h">
    
    <nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
        <div class="container-fluid">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="<?php echo e(url ('/')); ?>">
                        <img src="<?php echo e(asset('/images/saveta-removebg-preview.png')); ?>" alt="Logo Saveta" style="height: 3rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-black text-primary display-7" href="<?php echo e(url ('/')); ?>">SAVETA</a></span>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-bs-toggle="collapse" data-target="#navbarSupportedContent" data-bs-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav nav-dropdown nav-right" data-app-modern-menu="true"><li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="<?php echo e(url ('/')); ?>">
                            Home</a></li>
                    <li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="<?php echo e(url ('about')); ?>">
                            About us</a></li>
                    <li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="../../../catalog_mysql.php">
                            Products</a></li>
                    <li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="<?php echo e(url ('contact')); ?>">Contacts</a>
                    </li></ul>
                
                
            </div>
        </div>
    </nav>
</section>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\tes1\resources\views/partials/navbar.blade.php ENDPATH**/ ?>