<!DOCTYPE html>
<html  >
<head>
  
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <meta name="twitter:card" content="summary_large_image"/>
  <meta name="twitter:image:src" content="">
  <meta property="og:image" content="">
  <meta name="twitter:title" content="Home">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="<?php echo e(asset('/images/saveta-removebg-preview.png')); ?>" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Products</title>
  <link rel="stylesheet" href="<?php echo e(asset('/web/assets/mobirise-icons2/mobirise2.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/bootstrap/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/bootstrap/css/bootstrap-grid.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/bootstrap/css/bootstrap-reboot.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/dropdown/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/socicon/css/styles.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/theme/css/style.css')); ?>">
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap"></noscript>
  <link rel="preload" as="style" href="<?php echo e(asset('/mobirise/css/mbr-additional.css')); ?>"><link rel="stylesheet" href="<?php echo e(asset('/mobirise/css/mbr-additional.css')); ?>" type="text/css">
  
  
  
  
</head>
<body>
  
<section data-bs-version="5.1" class="menu menu3 cid-t4Ly7ne41J" once="menu" id="menu3-1h">
    
    <nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
        <div class="container-fluid">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="<?php echo e(url ('/')); ?>">
                        <img src="<?php echo e(asset('/images/saveta-removebg-preview.png')); ?>" alt="Logo Saveta" style="height: 3rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-black text-primary display-7" href="<?php echo e(url ('/')); ?>">SAVETA</a></span>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-bs-toggle="collapse" data-target="#navbarSupportedContent" data-bs-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav nav-dropdown nav-right" data-app-modern-menu="true"><li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="<?php echo e(url ('/')); ?>">
                            Home</a></li>
                    <li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="<?php echo e(url ('about')); ?>">
                            About us</a></li>
                    <li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="<?php echo e(url ('listdata')); ?>">
                            Products</a></li>
                    <li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="<?php echo e(url ('contact')); ?>">Contacts</a>
                    </li></ul>
                
                
            </div>
        </div>
    </nav>
</section>

<section data-bs-version="5.1" class="header13 cid-t7QT2eNoVu" id="header13-1w" style="background-image: url(<?php echo e(asset('images/mbr.jpg')); ?>)">

    

    
    

    <div class="align-center container-fluid">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-11">
                <h1 class="mbr-section-title mbr-fonts-style mb-3 display-1"><strong>OUR PRODUCTS</strong></h1>
                
                <p class="mbr-text mbr-fonts-style mb-3 display-7">&nbsp;</p>
                
                
            </div>
        </div>
    </div>
</section>

<section data-bs-version="5.1" class="features12 cid-t7QT2fhH1C" id="features13-1x">

    

    
    
    <div class="container">
        <h1>Cupcakes World
            <small class="text-muted">Our Products</small>
        </h1>
        <div class="row">
            <?php $__currentLoopData = $cupcakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cupcake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card">
                    <a href="<?php echo e(url ('detail?id='.$cupcake->IdCupcake)); ?>">
                        <img src="<?php echo e(asset('images/'.$cupcake->Image)); ?>" class="card-img-top" alt="<?php echo e($cupcake->Image); ?>">
                    </a>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-7">
                                <h5 class="card-title"><?php echo e($cupcake->Name); ?></h5>
                            </div>
                            <div class="col-md-5 text-right">
                                <p class="card-text">Price $<?php echo e($cupcake->Price); ?></p>
                            </div>
                        </div>
                        <a href="<?php echo e(url ('detail/'.$cupcake->IdCupcake)); ?>" class="btn btn-primary">See Product</a>
                    </div>
                </div>
                <br>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
        </div>
    </div>
</section>

<section data-bs-version="5.1" class="footer6 cid-t4LypC5PcJ" once="footers" id="footer6-5">

    

    

    <div class="container">
        <div class="row content mbr-white">
            <div class="col-12 col-md-3 col-lg-2 mbr-fonts-style display-7">
                <div class="image-wrapper">
                    <img src="<?php echo e(asset('/images/saveta-removebg-preview.png')); ?>" alt="Mobirise Website Builder">
                </div>
            </div>
            <div class="col-12 col-md-3 col-lg-3 mbr-fonts-style display-7">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7">
                    <strong>PT. Sarana Veterinaria Jaya Abadi</strong></h5>
                <ul class="list mbr-fonts-style mb-4 display-4">
                    <li class="mbr-text item-wrap">
                        <p>Taman Tekno BSD, Jl. Sektor 11 No.5, Setu, Kec.Setu, Kota Tangerang Selatan, Banten 15314</p>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-md-3 col-lg-2 mbr-fonts-style display-7">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7">
                    <strong>Links</strong>
                </h5>
                <ul class="list mbr-fonts-style mb-4 display-4">
                    <li class="mbr-text item-wrap">
                        <a class="text-primary" href="">Our Bussiness Product</a>
                    </li>
                    <li class="mbr-text item-wrap">
                        <a class="text-primary" href="">About Us</a>
                    </li>
                    <li class="mbr-text item-wrap">
                        <a class="text-primary" href="">Legacy Branch Company</a>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-md-3 col-lg-2 mbr-fonts-style display-7">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7">
                    <strong>Contact</strong>
                </h5>
                <ul class="list mbr-fonts-style mb-4 display-4">
                    <li class="mbr-text item-wrap">
                        <p>saveta@gmail.com</p>
                    </li>
                    <li class="mbr-text item-wrap">
                        <p>021 8906 2133</p>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-md-6 col-lg-2">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7">
                    <strong>Our Location</strong>
                </h5>
                <div class="google-map"><iframe frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyDk89J4FSunMF33ruMVWJaJht_Ro0kvoXs&amp;q=Taman Tekno BSD, Jl. Sektor 11 No.5, Setu, Kec.Setu, Kota Tangerang Selatan, Banten 15314" allowfullscreen=""></iframe></div>
            </div>
        </div>
        <div class="footer-lower">
            <div class="media-container-row">
                <div class="col-sm-12">
                    <hr>
                </div>
            </div>
            <div class="col-sm-12 copyright pl-0">
                <p class="mbr-text mbr-fonts-style mbr-white display-7">
                    © Copyright 2025 - All Rights Reserved
                </p>
            </div>
        </div>
    </div>
</section><section><a href="https://mobiri.se"></a><a href="https://mobiri.se"></a></section><script src="<?php echo e(asset('/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>  <script src="<?php echo e(asset('/smoothscroll/smooth-scroll.js')); ?>"></script>  <script src="<?php echo e(asset('/ytplayer/index.js')); ?>"></script>  <script src="<?php echo e(asset('/dropdown/js/navbar-dropdown.js')); ?>"></script>  <script src="<?php echo e(asset('/theme/js/script.js')); ?>"></script>  
  
  
</body>
</html><?php /**PATH C:\xampp\htdocs\tes1\resources\views/cupcakes/catalog.blade.php ENDPATH**/ ?>