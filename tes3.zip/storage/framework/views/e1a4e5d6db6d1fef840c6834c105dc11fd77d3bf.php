<?php $__env->startSection("content"); ?>
<section data-bs-version="5.1" class="footer6 cid-t4LypC5PcJ" once="footers" id="footer6-5">

    

    

    <div class="container">
        <div class="row content mbr-white">
            <div class="col-12 col-md-3 col-lg-2 mbr-fonts-style display-7">
                <div class="image-wrapper">
                    <img src="<?php echo e(asset('/images/saveta-removebg-preview.png')); ?>" alt="Mobirise Website Builder">
                </div>
            </div>
            <div class="col-12 col-md-3 col-lg-3 mbr-fonts-style display-7">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7">
                    <strong>PT. Sarana Veterinaria Jaya Abadi</strong></h5>
                <ul class="list mbr-fonts-style mb-4 display-4">
                    <li class="mbr-text item-wrap">
                        <p>Taman Tekno BSD, Jl. Sektor 11 No.5, Setu, Kec.Setu, Kota Tangerang Selatan, Banten 15314</p>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-md-3 col-lg-2 mbr-fonts-style display-7">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7">
                    <strong>Links</strong>
                </h5>
                <ul class="list mbr-fonts-style mb-4 display-4">
                    <li class="mbr-text item-wrap">
                        <a class="text-primary" href="">Our Bussiness Product</a>
                    </li>
                    <li class="mbr-text item-wrap">
                        <a class="text-primary" href="">About Us</a>
                    </li>
                    <li class="mbr-text item-wrap">
                        <a class="text-primary" href="">Legacy Branch Company</a>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-md-3 col-lg-2 mbr-fonts-style display-7">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7">
                    <strong>Contact</strong>
                </h5>
                <ul class="list mbr-fonts-style mb-4 display-4">
                    <li class="mbr-text item-wrap">
                        <p>saveta@gmail.com</p>
                    </li>
                    <li class="mbr-text item-wrap">
                        <p>021 8906 2133</p>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-md-6 col-lg-2">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7">
                    <strong>Our Location</strong>
                </h5>
                <div class="google-map"><iframe frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyDk89J4FSunMF33ruMVWJaJht_Ro0kvoXs&amp;q=Taman Tekno BSD, Jl. Sektor 11 No.5, Setu, Kec.Setu, Kota Tangerang Selatan, Banten 15314" allowfullscreen=""></iframe></div>
            </div>
        </div>
        <div class="footer-lower">
            <div class="media-container-row">
                <div class="col-sm-12">
                    <hr>
                </div>
            </div>
            <div class="col-sm-12 copyright pl-0">
                <p class="mbr-text mbr-fonts-style mbr-white display-7">
                    © Copyright 2025 - All Rights Reserved
                </p>
            </div>
        </div>
    </div>
</section><section><a href="https://mobiri.se"></a><a href="https://mobiri.se"></a></section><script src="<?php echo e(asset('/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>  <script src="<?php echo e(asset('/smoothscroll/smooth-scroll.js')); ?>"></script>  <script src="<?php echo e(asset('/ytplayer/index.js')); ?>"></script>  <script src="<?php echo e(asset('/dropdown/js/navbar-dropdown.js')); ?>"></script>  <script src="<?php echo e(asset('/theme/js/script.js')); ?>"></script>  
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\tes1\resources\views/partials/footer.blade.php ENDPATH**/ ?>